let essays = new Vue({
  el:'#essay',
  data: {
    ispush: 1,
  },
  methods: {
    tab_list:function(list){
      this.ispush = parseInt(list)
    }
  },
})