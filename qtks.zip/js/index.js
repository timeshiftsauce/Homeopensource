let a = [
  "https://cn.bing.com/search?q=",
  "&form=ANNTH1&refig=4700dcc4e8484094ae4bda33c7d2bc48",
];
let fangsi = document.getElementById("fangsi");
let xz = document.getElementById("xz");
let boy = document.getElementById("boy");
let qh = document.getElementById("qh-ul");
let ico_fs = document.getElementById("ico-fs");

WIDGET = {
  CONFIG: {
    modules: "01234",
    background: "4",
    tmpColor: "FFFFFF",
    tmpSize: "16",
    cityColor: "FFFFFF",
    citySize: "16",
    aqiColor: "FFFFFF",
    aqiSize: "16",
    weatherIconSize: "24",
    alertIconSize: "18",
    padding: "3px 10px 3px 10px",
    shadow: "1",
    language: "auto",
    borderRadius: "90",
    fixed: "false",
    vertical: "top",
    horizontal: "left",
    key: "f1b8c11ed9ac43b7a38fe717f071d41d",
  },
};
(function (d) {
  var c = d.createElement("link");
  c.rel = "stylesheet";
  c.href =
    "https://widget.qweather.net/simple/static/css/he-simple.css?v=1.4.0";
  var s = d.createElement("script");
  s.src = "https://widget.qweather.net/simple/static/js/he-simple.js?v=1.4.0";
  var sn = d.getElementsByTagName("script")[0];
  sn.parentNode.insertBefore(c, sn);
  sn.parentNode.insertBefore(s, sn);
})(document);
function getTime() {
  let time = Date().slice(16, 21);
  document.getElementById("time").innerHTML = time;
}
setInterval("getTime()", 2000);
let sousuo = document.getElementById("sousuo");
let inputs = document.getElementById("inputss");
sousuo.onclick = function () {
  open(a[0] + inputs.value + a[1]);
};

boy.addEventListener("keyup", function (event) {
  event.preventDefault();
  if (event.key == "Enter") {
    open(a[0] + inputs.value + a[1]);
  }
});
let xs = 0;
fangsi.onclick = function () {
  if (xs == 0) {
    xz.style.cssText = "display:block";
    setTimeout(() => (xs = 1), 100);
    console.log(xs);
  }
};
boy.onclick = function () {
  if (xs == 1) {
    xz.style.cssText = "display:none";
    xs = 0;
  }
  setTimeout(() => (ul_list.style.cssText = "display:none"), 100);
};
let iconfont = document.getElementsByClassName("6");
console.log(iconfont[0]);
iconfont[0].onclick = function () {
  ico_fs.className = "iconfont icon-Bing 1";
  a = [
    "https://cn.bing.com/search?q=",
    "&form=ANNTH1&refig=4700dcc4e8484094ae4bda33c7d2bc48",
  ];
};
iconfont[1].onclick = function () {
  ico_fs.className = "iconfont icon-BaiDu 1";
  a = [
    "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd=",
    "&fenlei=256&rsv_pq=f96640af000e7281&rsv_t=c30381L7fT%2FBJKR10oCY%2FGtx8vbbCOfBkxVXZ1I%2FT2%2Bp4JGLQF5i3itftXSK&rqlang=en&rsv_enter=1&rsv_dl=tb&rsv_sug3=3&rsv_sug1=3&rsv_sug7=101&rsv_sug2=0&rsv_btype=i&inputT=450&rsv_sug4=923",
  ];
};
iconfont[2].onclick = function () {
  ico_fs.className = "iconfont icon-Sougou 1";
  a = [
    "https://www.sogou.com/web?query=",
    "&_asf=www.sogou.com&_ast=1658570773&w=01019900&p=40040100&ie=utf8&from=index-nologin&s_from=index&sut=1969&sst0=1658570773044&lkt=3%2C1658570771075%2C1658570771353&sugsuv=1658151593279288&sugtime=1658570773044",
  ];
};
iconfont[3].onclick = function () {
  ico_fs.className = "iconfont icon-360logo 1";
  a = [
    "https://www.so.com/s?ie=utf-8&fr=so.com&src=home_so.com&ssid=&nlpv=basezc&q=",
    "",
  ];
};
let ul_list = document.getElementById("ul_list");
let url1 = "http://suggestion.baidu.com/su?wd=";
let url2 = "&cb=";
inputs.onkeyup = function () {
  if (inputs.value.length > 0) {
    ul_list.style.cssText = "";
  }
  let script = document.createElement("script");
  script.src = url1 + this.value + url2 + "Search_Data";
  document.body.appendChild(script);
};
function Search_Data(data) {
  var arr = data.s;
  ul_list.innerHTML = "";
  for (var i = 0; i < arr.length; i++) {
    var li = document.createElement("li");
    li.innerText = arr[i];
    ul_list.appendChild(li);
  }
}
boy.addEventListener("keyup", function (event) {
  event.preventDefault();
  if (event.key == "Backspace") {
    console.log(66);
    if (inputs.value.length == 0) {
      ul_list.style.cssText = "display:none";
    }
  }
});
ul_list.style.cssText = "display:none"
var ul_list_1 = document.getElementById("ul_list");

ul_list_1.addEventListener("click", function (e) {
  inputs.value = e.target.innerText;
  setTimeout(() => (open(a[0] + inputs.value + a[1])), 1000)
  console.log(e.target);
});

inputs.onfocus = function () {
  if (inputs.value.length != 0) {
    ul_list.style.cssText = "display:block";
  }
};
inputs.onclick = function (event) {
  event = event || window.event;
  event.cancelBubble = true;
};
