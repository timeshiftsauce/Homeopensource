let essays = new Vue({
  el:'#essay_box',
  data: {
    ispush: 1,
  },
  methods: {
    tab_list:function(list){
      this.ispush = parseInt(list)
    }
  },
})