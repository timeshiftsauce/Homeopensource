let essays = new Vue({
  el:'#essay_box',
  data (){
    return{
      ispush: 1,
      essay_content:[{
          'essay_img':'./image/essay/01c6215a6c1526a80120a1233f4b76.jpg@1280w_1l_2o_100sh.jpg',
          'essay_title':'my one title',
          'essay_text':'第一篇文章',
          'category':'code'
        },
        {
          'essay_img':'./image/essay/r-c.jpg',
          'essay_title':'my two title',
          'essay_text':'第二篇文章很长很长很长很长很长很长很长很长很长很长很长',
          'category':'tutorial'
        },
        {
          'essay_img':'./image/essay/zpsd1722.jpg',
          'essay_title':'my three title',
          'essay_text':'第三篇文章',
          'category':'other'
        }
      ],
    }
    
  },
  methods: {
    tab_list:function(list){
      this.ispush = parseInt(list);
    }
  },
})